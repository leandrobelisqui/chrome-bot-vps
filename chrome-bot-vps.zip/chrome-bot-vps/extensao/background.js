setInterval(() => {
  chrome.tabs.create({ url: "https://example.com" });
}, 300000); // 5 minutos